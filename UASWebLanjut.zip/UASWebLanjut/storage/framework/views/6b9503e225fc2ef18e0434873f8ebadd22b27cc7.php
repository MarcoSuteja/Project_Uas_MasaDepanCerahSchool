<div class="col-lg-<?php echo e($col ?? ''); ?>">
	<div class="card">
		<div class="card-header"><?php echo e($header ?? ''); ?></div>
		<div class="card-body">
			<?php echo e($slot); ?>

		</div>
	</div>
</div><?php /**PATH C:\xampp\htdocs\laraschool-master\resources\views/components/card.blade.php ENDPATH**/ ?>